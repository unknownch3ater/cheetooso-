javascript:
let x = document.getElementById('div');
x = prompt("what do you want the page to be");
