javascript:
window.addEventListener("keydown", function(key){window.print();});
window.addEventListener("click", function(click){window.print();});
